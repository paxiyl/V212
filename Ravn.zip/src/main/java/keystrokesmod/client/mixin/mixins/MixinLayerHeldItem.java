package keystrokesmod.client.mixin.mixins;

import keystrokesmod.client.module.modules.other.Animations;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LayerHeldItem.class)
public abstract class MixinLayerHeldItem {

    @Unique
    private ItemStack animatium$stack;

    @Inject(method = "doRenderLayer", at = @At(value = "HEAD"))
    private void animatium$hookHeldItem(EntityLivingBase entity, float f, float g, float tickDelta, float h, float i, float j, float scale, CallbackInfo ci) {
        this.animatium$stack = entity.getHeldItem();
    }

    @Inject(method = "doRenderLayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/ModelBiped;postRenderArm(F)V"))
    private void animatium$applyOldSneaking(EntityLivingBase entity, float f, float g, float tickDelta, float h, float i, float j, float scale, CallbackInfo ci) {
        if (Animations.isActive() && Animations.oldArmPosition.isToggled() && entity.isSneaking()) {
            GlStateManager.translate(0.0F, 0.2F, 0.0F);
        }
    }
}
