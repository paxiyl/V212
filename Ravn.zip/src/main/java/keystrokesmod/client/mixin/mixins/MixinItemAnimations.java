package keystrokesmod.client.mixin.mixins;

import keystrokesmod.client.module.modules.other.Animations;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Item.class)
public abstract class MixinItemAnimations {

    @Inject(method = "shouldCauseReequipAnimation", at = @At("HEAD"), cancellable = true, remap = false)
    private void animatium$modifyReequip(ItemStack oldStack, ItemStack newStack, boolean slotChanged, CallbackInfoReturnable<Boolean> cir) {
        if (!Animations.isActive()) return;

        if (Animations.itemSwitchMode.getMode() == Animations.ItemSwitchMode.DISABLED) {
            cir.setReturnValue(false);
        } else if (Animations.fixReequip.isToggled()
                && Animations.itemSwitchMode.getMode() != Animations.ItemSwitchMode.V1_7
                && !slotChanged) {
            cir.setReturnValue(false);
        } else if (Animations.itemSwitchMode.getMode() == Animations.ItemSwitchMode.V1_7) {
            cir.setReturnValue(!Animations.fixReequip.isToggled() || slotChanged
                    || Minecraft.getMinecraft().currentScreen instanceof GuiContainer);
        }
    }
}
