package keystrokesmod.client.mixin.mixins;

import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.modules.combat.HitSelect;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerControllerMP.class)
public class MixinPlayerControllerMP {

    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true)
    public void onAttackEntity(EntityPlayer player, Entity target, CallbackInfo ci) {
        if (!(target instanceof EntityLivingBase))
            return;

        if (HitSelect.shouldCancelAttack((EntityLivingBase) target))
            ci.cancel();
    }
}
