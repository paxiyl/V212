package keystrokesmod.client.module.modules.player;

import java.lang.reflect.Field;

import com.google.common.eventbus.Subscribe;

import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovementInput;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

public class GodPlace extends Module {

    public static SliderSetting delay;
    public static TickSetting faceLock;
    public static TickSetting cancelDownFace;
    public static TickSetting noJumpDelay;
    public static TickSetting alerts;
    public static TickSetting debug;

    private static final Field rightClickDelayTimerField;
    private static final Field blockHitDelayField;
    private static final Field jumpField;

    static {
        rightClickDelayTimerField = ReflectionHelper.findField(Minecraft.class, "field_71467_ac", "rightClickDelayTimer");
        if (rightClickDelayTimerField != null)
            rightClickDelayTimerField.setAccessible(true);

        blockHitDelayField = ReflectionHelper.findField(PlayerControllerMP.class, "field_78778_q", "blockHitDelay");
        if (blockHitDelayField != null)
            blockHitDelayField.setAccessible(true);

        Field f = null;
        try {
            f = ReflectionHelper.findField(MovementInput.class, "field_78800_z", "jump");
        } catch (Exception ignored) {
        }
        jumpField = f;
        if (jumpField != null)
            jumpField.setAccessible(true);
    }

    private boolean locked = false;
    private EnumFacing lockedFace = null;

    public GodPlace() {
        super("GodPlace", ModuleCategory.player);
        this.registerSetting(new DescriptionSetting("Fast block placement with instant face-lock."));
        this.registerSetting(delay = new SliderSetting("Delay", 0.0D, 0.0D, 5.0D, 1.0D));
        this.registerSetting(faceLock = new TickSetting("Face lock", true));
        this.registerSetting(cancelDownFace = new TickSetting("Cancel down face", true));
        this.registerSetting(noJumpDelay = new TickSetting("No jump delay", false));
        this.registerSetting(alerts = new TickSetting("Alerts", true));
        this.registerSetting(debug = new TickSetting("Debug", false));
    }

    @Override
    public boolean canBeEnabled() {
        return rightClickDelayTimerField != null;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        locked = false;
        lockedFace = null;
        if (alerts.isToggled())
            Utils.Player.sendMessageToSelf("\u00a75[GodPlace] \u00a7aON \u00a77(delay: " + (int) delay.getInput() + ")");
    }

    @Override
    public void onDisable() {
        super.onDisable();
        locked = false;
        lockedFace = null;
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null)
            return;

        manageDelay();

        if (noJumpDelay.isToggled() && jumpField != null && mc.thePlayer != null
                && mc.gameSettings.keyBindJump.isKeyDown()) {
            try {
                jumpField.setBoolean(mc.thePlayer.movementInput, true);
            } catch (Exception ignored) {
            }
        }

        if (!mc.gameSettings.keyBindUseItem.isKeyDown()) {
            if (locked) {
                locked = false;
                lockedFace = null;
            }
        }
    }

    private void manageDelay() {
        int d = (int) delay.getInput();

        if (rightClickDelayTimerField != null) {
            try {
                if (d == 0)
                    rightClickDelayTimerField.set(mc, 0);
                else {
                    int current = rightClickDelayTimerField.getInt(mc);
                    if (current > d)
                        rightClickDelayTimerField.set(mc, d);
                }
            } catch (Exception ignored) {
            }
        }

        // The actual per-place cooldown lives in PlayerControllerMP.blockHitDelay (set to 5
        // after every successful block placement). If this is not zeroed too, placement is
        // still gated to ~1 block / 5 ticks even with rightClickDelayTimer = 0, which is why
        // "delay 0" felt slow. Drive it down to match the requested delay.
        if (blockHitDelayField != null && mc.playerController != null) {
            try {
                if (d == 0)
                    blockHitDelayField.set(mc.playerController, 0);
                else {
                    int current = blockHitDelayField.getInt(mc.playerController);
                    if (current > d)
                        blockHitDelayField.set(mc.playerController, d);
                }
            } catch (Exception ignored) {
            }
        }
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (!faceLock.isToggled())
            return;
        if (!(fe.getEvent() instanceof PlayerInteractEvent))
            return;

        PlayerInteractEvent event = (PlayerInteractEvent) fe.getEvent();
        if (event.action != PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK)
            return;
        if (event.entityPlayer != mc.thePlayer)
            return;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock))
            return;

        EnumFacing hitFace = event.face;

        if (cancelDownFace.isToggled() && hitFace == EnumFacing.DOWN) {
            event.setCanceled(true);
            return;
        }

        if (!locked) {
            locked = true;
            lockedFace = hitFace;
            if (debug.isToggled())
                Utils.Player.sendMessageToSelf("\u00a78[GP-DEBUG] \u00a77LOCKED " + hitFace.name().toUpperCase());
            return;
        }

        if (hitFace != lockedFace) {
            event.setCanceled(true);
            if (debug.isToggled())
                Utils.Player.sendMessageToSelf(
                        "\u00a78[GP-DEBUG] \u00a77CANCELLED face " + hitFace.name().toUpperCase());
        }
    }
}
