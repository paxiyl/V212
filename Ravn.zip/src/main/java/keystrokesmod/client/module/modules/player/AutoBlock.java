package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.Render2DEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import org.lwjgl.opengl.GL11;

/**
 * Predictive horizontal auto-block: places a 3-block wall perpendicular to a
 * moving target's path. All placement is server-authoritative and uses normal
 * Minecraft block-interaction mechanics from the local player's POV.
 */
public class AutoBlock extends Module {

    // ========================= SETTINGS =========================

    public static SliderSetting range;
    public static SliderSetting predictionTicks;
    public static SliderSetting placementReach;
    public static SliderSetting wallSpacing;
    public static SliderSetting frontDistance;
    public static SliderSetting tickDelay;
    public static SliderSetting confirmDelay;
    public static SliderSetting maxRetries;
    public static SliderSetting rotationSpeed;
    public static TickSetting predictiveRotation;
    public static TickSetting debug;
    public static TickSetting renderTarget;
    public static TickSetting renderPredicted;
    public static TickSetting renderBlocks;
    public static TickSetting blockPreview;
    public static SliderSetting previewLineWidth;
    public static SliderSetting previewAlpha;
    public static TickSetting renderConfirmed;

    // ========================= STATE MACHINE =========================

    private static final int S_IDLE = 0;
    private static final int S_ACQUIRING = 1;
    private static final int S_COMPUTING = 2;
    private static final int S_ROTATING = 3;
    private static final int S_PLACING = 4;
    private static final int S_CONFIRMING = 5;
    private static final int S_COMPLETE = 6;

    private int state;
    private int blockIdx;
    private int tickAccum;
    private int confirmAccum;
    private int retryAccum;
    private int acquireTicks;
    private int completeTicks;

    // ========================= ROTATION =========================

    private float targetYaw, targetPitch;
    private boolean needsRotation;

    // ========================= WALL DATA =========================

    private final BlockPos[] wallPos = new BlockPos[3];
    private final BlockPos[] supportPos = new BlockPos[3];
    private final EnumFacing[] face = new EnumFacing[3];
    private final Vec3[] hitVec = new Vec3[3];
    private final WallResult[] result = new WallResult[3];
    private Block expectedBlock;

    // ========================= TARGET =========================

    private EntityPlayer target;
    private double prevTX, prevTZ;
    private double velX, velZ;
    private boolean hasVel;

    // ========================= PREDICTION =========================

    private double predX, predZ, predYaw;

    // ========================= STALE TRACKING =========================

    private double stalePlayerX, stalePlayerZ;
    private double staleVelX, staleVelZ;

    // ========================= INVENTORY =========================

    private int savedSlot = -1;
    private int blockSlot = -1;

    public AutoBlock() {
        super("AutoBlock", ModuleCategory.player);
        this.registerSetting(new DescriptionSetting(
                "Predictive 3-block horizontal wall placement across a moving target's path."));
        this.registerSetting(range = new SliderSetting("Target range", 20.0D, 4.0D, 40.0D, 1.0D));
        this.registerSetting(predictionTicks = new SliderSetting("Prediction ticks", 10.0D, 1.0D, 40.0D, 1.0D));
        this.registerSetting(placementReach = new SliderSetting("Placement reach", 4.5D, 3.0D, 6.0D, 0.1D));
        this.registerSetting(wallSpacing = new SliderSetting("Wall spacing", 1.0D, 0.5D, 3.0D, 0.5D));
        this.registerSetting(frontDistance = new SliderSetting("Front distance", 1.5D, 1.0D, 5.0D, 0.5D));
        this.registerSetting(tickDelay = new SliderSetting("Tick delay", 1.0D, 0.0D, 4.0D, 1.0D));
        this.registerSetting(confirmDelay = new SliderSetting("Confirm ticks", 3.0D, 1.0D, 10.0D, 1.0D));
        this.registerSetting(maxRetries = new SliderSetting("Max retries", 2.0D, 0.0D, 5.0D, 1.0D));
        this.registerSetting(rotationSpeed = new SliderSetting("Rotation speed", 180.0D, 30.0D, 180.0D, 10.0D));
        this.registerSetting(predictiveRotation = new TickSetting("Predictive rotation", true));
        this.registerSetting(debug = new TickSetting("Debug", false));
        this.registerSetting(renderTarget = new TickSetting("Render target", true));
        this.registerSetting(renderPredicted = new TickSetting("Render predicted", true));
        this.registerSetting(renderBlocks = new TickSetting("Render blocks", true));
        this.registerSetting(blockPreview = new TickSetting("Block preview", true));
        this.registerSetting(previewLineWidth = new SliderSetting("Preview line width", 2.0D, 1.0D, 5.0D, 0.5D));
        this.registerSetting(previewAlpha = new SliderSetting("Preview alpha", 1.0D, 0.1D, 1.0D, 0.1D));
        this.registerSetting(renderConfirmed = new TickSetting("Render confirmed", false));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        reset();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        restoreSlot();
        reset();
    }

    // ========================= TICK (STATE MACHINE) =========================

    @Subscribe
    public void onTick(TickEvent e) {
        if (!Utils.Player.isPlayerInGame() || mc.thePlayer == null || mc.theWorld == null)
            return;
        if (mc.currentScreen != null)
            return;

        if (state > S_IDLE && state < S_COMPLETE && !targetValid()) {
            debugMsg("\u00a7cTarget lost");
            restoreSlot();
            reset();
            return;
        }

        tickAccum++;
        if (tickAccum < (int) tickDelay.getInput())
            return;
        tickAccum = 0;

        switch (state) {
            case S_IDLE:
                tickIdle();
                break;
            case S_ACQUIRING:
                tickAcquiring();
                break;
            case S_COMPUTING:
                tickComputing();
                break;
            case S_ROTATING:
                tickRotating();
                break;
            case S_PLACING:
                tickPlacing();
                break;
            case S_CONFIRMING:
                tickConfirming();
                break;
            case S_COMPLETE:
                tickComplete();
                break;
        }
    }

    private void tickIdle() {
        EntityPlayer found = AutoBlockHelper.findTarget(range.getInput());
        if (found == null) {
            target = null;
            hasVel = false;
            return;
        }
        if (found != target) {
            target = found;
            hasVel = false;
            acquireTicks = 0;
        }
        state = S_ACQUIRING;
    }

    private void tickAcquiring() {
        if (!targetValid()) {
            restoreSlot();
            reset();
            return;
        }

        if (hasVel) {
            double[] v = AutoBlockHelper.calcVelocity(target, prevTX, prevTZ);
            velX = v[0];
            velZ = v[1];
        }
        prevTX = target.posX;
        prevTZ = target.posZ;
        hasVel = true;
        acquireTicks++;

        if (acquireTicks >= 2 && AutoBlockHelper.isMoving(velX, velZ, 0.01D)) {
            state = S_COMPUTING;
        }
    }

    private void tickComputing() {
        double ticks = predictionTicks.getInput();
        predX = AutoBlockHelper.predictX(target.posX, velX, ticks);
        predZ = AutoBlockHelper.predictZ(target.posZ, velZ, ticks);
        int wallY = (int) Math.floor(AutoBlockHelper.predictY(target, ticks));
        predYaw = AutoBlockHelper.directionDegrees(velX, velZ);

        BlockPos predCenter = new BlockPos((int) Math.floor(predX), wallY, (int) Math.floor(predZ));
        if (!AutoBlockHelper.isWithinReach(predCenter, placementReach.getInput())) {
            debugMsg("\u00a7cPrediction out of reach");
            restoreSlot();
            reset();
            return;
        }

        BlockPos[] w = AutoBlockHelper.calcWall(predX, predZ, wallY, velX, velZ,
                wallSpacing.getInput(), frontDistance.getInput());
        if (w == null) {
            debugMsg("\u00a7cWall computation failed");
            restoreSlot();
            reset();
            return;
        }

        if (savedSlot == -1)
            savedSlot = mc.thePlayer.inventory.currentItem;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) {
            blockSlot = AutoBlockHelper.findBlockInHotbar();
            if (blockSlot == -1) {
                debugMsg("\u00a7cNo block in hotbar");
                restoreSlot();
                reset();
                return;
            }
            mc.thePlayer.inventory.currentItem = blockSlot;
            held = mc.thePlayer.getHeldItem();
        } else {
            blockSlot = mc.thePlayer.inventory.currentItem;
        }

        if (held == null || !(held.getItem() instanceof ItemBlock)) {
            debugMsg("\u00a7cNo block available");
            restoreSlot();
            reset();
            return;
        }

        expectedBlock = ((ItemBlock) held.getItem()).block;

        for (int i = 0; i < 3; i++) {
            wallPos[i] = w[i];
            result[i] = WallResult.WAITING;
            supportPos[i] = null;
            face[i] = null;
            hitVec[i] = null;

            if (!AutoBlockHelper.isChunkLoaded(wallPos[i])) {
                result[i] = WallResult.FAILED;
                continue;
            }
            if (!AutoBlockHelper.isBlockReplaceable(wallPos[i])) {
                result[i] = WallResult.FAILED;
                continue;
            }

            supportPos[i] = AutoBlockHelper.findSupportBlock(wallPos[i]);
            if (supportPos[i] == null) {
                result[i] = WallResult.NO_SUPPORT;
                continue;
            }

            face[i] = AutoBlockHelper.findPlacementFace(wallPos[i], supportPos[i]);
            if (face[i] == null) {
                result[i] = WallResult.NO_SUPPORT;
                continue;
            }

            hitVec[i] = AutoBlockHelper.computeHitVec(wallPos[i], face[i]);
        }

        stalePlayerX = mc.thePlayer.posX;
        stalePlayerZ = mc.thePlayer.posZ;
        staleVelX = velX;
        staleVelZ = velZ;

        blockIdx = nextWaiting(-1);
        if (blockIdx == -1) {
            debugMsg("\u00a7cNo blocks to place");
            restoreSlot();
            reset();
            return;
        }

        aimAtBlock(blockIdx);
        state = S_ROTATING;
        confirmAccum = 0;
        retryAccum = 0;
    }

    private void tickRotating() {
        if (isWallStale()) {
            debugMsg("\u00a7eWall stale, recomputing");
            restoreSlot();
            state = S_COMPUTING;
            savedSlot = -1;
            return;
        }

        if (needsRotation) {
            confirmAccum++;
            if (confirmAccum > 20) {
                result[blockIdx] = WallResult.FAILED;
                advance();
            }
            return;
        }

        if (!AutoBlockHelper.isWithinReach(wallPos[blockIdx], placementReach.getInput())) {
            result[blockIdx] = WallResult.OUT_OF_REACH;
            advance();
            return;
        }
        if (!AutoBlockHelper.isBlockReplaceable(wallPos[blockIdx])) {
            result[blockIdx] = WallResult.FAILED;
            advance();
            return;
        }
        if (!AutoBlockHelper.isChunkLoaded(wallPos[blockIdx])) {
            result[blockIdx] = WallResult.FAILED;
            advance();
            return;
        }

        if (mc.thePlayer.inventory.currentItem != blockSlot)
            mc.thePlayer.inventory.currentItem = blockSlot;

        state = S_PLACING;
    }

    private void tickPlacing() {
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)
                || ((ItemBlock) held.getItem()).block != expectedBlock) {
            result[blockIdx] = WallResult.FAILED;
            advance();
            return;
        }

        if (supportPos[blockIdx] == null) {
            result[blockIdx] = WallResult.NO_SUPPORT;
            advance();
            return;
        }

        boolean ok = doPlace(wallPos[blockIdx], supportPos[blockIdx], face[blockIdx], hitVec[blockIdx]);

        if (ok) {
            debugMsg("\u00a7aBlock " + (blockIdx + 1) + " placed");
            state = S_CONFIRMING;
            confirmAccum = 0;
        } else {
            retryAccum++;
            if (retryAccum >= (int) maxRetries.getInput()) {
                result[blockIdx] = WallResult.FAILED;
                advance();
            } else {
                aimAtBlock(blockIdx);
                state = S_ROTATING;
            }
        }
    }

    private void tickConfirming() {
        confirmAccum++;

        Block actual = mc.theWorld.getBlockState(wallPos[blockIdx]).getBlock();
        if (actual == expectedBlock) {
            result[blockIdx] = WallResult.CONFIRMED;
            debugMsg("\u00a7aBlock " + (blockIdx + 1) + " confirmed");
            advance();
            return;
        }

        if (confirmAccum >= (int) confirmDelay.getInput()) {
            result[blockIdx] = WallResult.FAILED;
            debugMsg("\u00a7cBlock " + (blockIdx + 1) + " confirm timeout");
            advance();
        }
    }

    private void tickComplete() {
        completeTicks++;
        if (completeTicks > 5) {
            restoreSlot();
            reset();
        }
    }

    // ========================= ROTATION (UPDATE EVENT) =========================

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!e.isPre() || !needsRotation || mc.thePlayer == null)
            return;

        float curYaw = mc.thePlayer.rotationYaw;
        float curPitch = mc.thePlayer.rotationPitch;
        float maxYaw = (float) rotationSpeed.getInput();

        float dYaw = MathHelper.wrapAngleTo180_float(targetYaw - curYaw);
        float dPitch = targetPitch - curPitch;

        float newYaw = curYaw + MathHelper.clamp_float(dYaw, -maxYaw, maxYaw);
        float newPitch = MathHelper.clamp_float(
                curPitch + MathHelper.clamp_float(dPitch, -maxYaw, maxYaw),
                -90.0F, 90.0F);

        e.setYaw(newYaw);
        e.setPitch(newPitch);
        mc.thePlayer.rotationYaw = newYaw;
        mc.thePlayer.rotationPitch = newPitch;
        mc.thePlayer.renderYawOffset = newYaw;
        mc.thePlayer.rotationYawHead = newYaw;

        if (Math.abs(dYaw) < 1.0F && Math.abs(dPitch) < 1.0F)
            needsRotation = false;
    }

    // ========================= STALE WALL DETECTION =========================

    private boolean isWallStale() {
        if (mc.thePlayer == null || target == null)
            return true;

        double playerDist = Math.sqrt(
                (mc.thePlayer.posX - stalePlayerX) * (mc.thePlayer.posX - stalePlayerX) +
                (mc.thePlayer.posZ - stalePlayerZ) * (mc.thePlayer.posZ - stalePlayerZ));
        if (playerDist > 2.0)
            return true;

        if (AutoBlockHelper.isMoving(velX, velZ, 0.01D) && AutoBlockHelper.isMoving(staleVelX, staleVelZ, 0.01D)) {
            double curAngle = Math.atan2(velX, velZ);
            double oldAngle = Math.atan2(staleVelX, staleVelZ);
            double angleDiff = Math.abs(Math.toDegrees(curAngle - oldAngle));
            if (angleDiff > 180) angleDiff = 360 - angleDiff;
            if (angleDiff > 30)
                return true;
        }

        for (int i = 0; i < 3; i++) {
            if (result[i] == WallResult.WAITING && wallPos[i] != null) {
                if (!AutoBlockHelper.isChunkLoaded(wallPos[i]) || !AutoBlockHelper.isBlockReplaceable(wallPos[i]))
                    return true;
            }
        }

        return false;
    }

    // ========================= STATE ADVANCEMENT =========================

    private void advance() {
        retryAccum = 0;
        int next = nextWaiting(blockIdx + 1);
        if (next != -1) {
            blockIdx = next;
            if (mc.thePlayer != null && blockSlot >= 0 && blockSlot < 9)
                mc.thePlayer.inventory.currentItem = blockSlot;
            aimAtBlock(blockIdx);
            state = S_ROTATING;
            confirmAccum = 0;
        } else {
            state = S_COMPLETE;
            completeTicks = 0;
        }
    }

    private int nextWaiting(int from) {
        for (int i = from; i < 3; i++)
            if (result[i] == WallResult.WAITING)
                return i;
        return -1;
    }

    // ========================= BLOCK PLACEMENT =========================

    private boolean doPlace(BlockPos target, BlockPos support, EnumFacing f, Vec3 hv) {
        if (mc.thePlayer == null || mc.theWorld == null)
            return false;
        if (!AutoBlockHelper.isBlockReplaceable(target))
            return false;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock))
            return false;

        boolean placed = mc.playerController.onPlayerRightClick(
                mc.thePlayer, mc.theWorld, held, support, f, hv);
        if (placed) {
            mc.thePlayer.swingItem();
            mc.getItemRenderer().resetEquippedProgress();
        }
        return placed;
    }

    private void aimAtBlock(int index) {
        if (hitVec[index] == null) {
            result[index] = WallResult.FAILED;
            advance();
            return;
        }
        float[] r = AutoBlockHelper.calcRotation(hitVec[index]);
        targetYaw = r[0];
        targetPitch = r[1];
        needsRotation = true;
        confirmAccum = 0;
    }

    private boolean targetValid() {
        return target != null && !target.isDead && target.getHealth() > 0
                && mc.theWorld != null && mc.theWorld.getEntityByID(target.getEntityId()) != null;
    }

    // ========================= INVENTORY =========================

    private void restoreSlot() {
        if (savedSlot >= 0 && savedSlot < 9 && mc.thePlayer != null)
            mc.thePlayer.inventory.currentItem = savedSlot;
        savedSlot = -1;
        blockSlot = -1;
    }

    // ========================= RESET =========================

    private void reset() {
        state = S_IDLE;
        target = null;
        hasVel = false;
        velX = velZ = 0;
        needsRotation = false;
        tickAccum = confirmAccum = retryAccum = acquireTicks = completeTicks = 0;
        blockIdx = -1;
        expectedBlock = null;
        for (int i = 0; i < 3; i++) {
            wallPos[i] = supportPos[i] = null;
            face[i] = null;
            hitVec[i] = null;
            result[i] = null;
        }
    }

    // ========================= DEBUG =========================

    private void debugMsg(String msg) {
        if (debug.isToggled())
            Utils.Player.sendMessageToSelf("[AutoBlock] " + msg);
    }

    // ========================= DEBUG HUD =========================

    @Subscribe
    public void onRender2D(Render2DEvent e) {
        if (!debug.isToggled() || !Utils.Player.isPlayerInGame())
            return;

        int y = 50;
        mc.fontRendererObj.drawStringWithShadow("\u00a7dAutoBlock", 4, y, 0xFFFFFF);
        y += 12;

        if (target != null) {
            drawLine(y, "Target", target.getName()); y += 10;
            drawLine(y, "Distance", String.format("%.1f", mc.thePlayer.getDistanceToEntity(target))); y += 10;
            drawLine(y, "Velocity", String.format("%.3f, %.3f", velX, velZ)); y += 10;
            drawLine(y, "Direction",
                    AutoBlockHelper.isMoving(velX, velZ, 0.01D)
                            ? AutoBlockHelper.directionName(velX, velZ)
                            : "STATIC"); y += 10;
            drawLine(y, "Pred X/Z", String.format("%.2f / %.2f", predX, predZ)); y += 10;
        }

        y += 4;
        drawLine(y, "State", stateName()); y += 10;
        if (blockIdx >= 0) {
            drawLine(y, "Block", (blockIdx + 1) + "/3"); y += 10;
        }
        y += 4;

        String[] names = {"LEFT", "CENTER", "RIGHT"};
        for (int i = 0; i < 3; i++) {
            String s;
            int c;
            if (result[i] == null) {
                s = "\u00a77N/A"; c = 0x808080;
            } else {
                switch (result[i]) {
                    case CONFIRMED:    s = "\u00a7aCONFIRMED";  c = 0x55FF55; break;
                    case WAITING:      s = "\u00a7eWAITING";    c = 0xFFFF55; break;
                    case NO_SUPPORT:   s = "\u00a7cNO_SUPPORT"; c = 0xFF5555; break;
                    case FAILED:       s = "\u00a7cFAILED";     c = 0xFF5555; break;
                    case OUT_OF_REACH: s = "\u00a7cOUT_OF_REACH"; c = 0xFF5555; break;
                    default:           s = "\u00a77" + result[i].name(); c = 0xAAAAAA;
                }
            }
            mc.fontRendererObj.drawStringWithShadow(
                    "  \u00a77" + names[i] + ": " + s, 4, y, c);
            y += 10;
        }
    }

    private void drawLine(int y, String label, String value) {
        mc.fontRendererObj.drawStringWithShadow(
                "\u00a77" + label + ": \u00a7f" + value, 4, y, 0xFFFFFF);
    }

    private String stateName() {
        switch (state) {
            case S_IDLE:      return "IDLE";
            case S_ACQUIRING: return "ACQUIRING";
            case S_COMPUTING: return "COMPUTING";
            case S_ROTATING:  return "ROTATING";
            case S_PLACING:   return "PLACING";
            case S_CONFIRMING:return "CONFIRMING";
            case S_COMPLETE:  return "COMPLETE";
            default:          return "?";
        }
    }

    // ========================= WORLD RENDERING =========================

    @Subscribe
    public void onRenderWorldLast(ForgeEvent fe) {
        if (!(fe.getEvent() instanceof RenderWorldLastEvent))
            return;
        if (!Utils.Player.isPlayerInGame() || mc.thePlayer == null)
            return;

        if (debug.isToggled()) {
            renderDebugWorld();
        }

        if (blockPreview.isToggled() && state >= S_ROTATING && state <= S_CONFIRMING) {
            renderPreview();
        }
    }

    private void renderDebugWorld() {
        if (renderTarget.isToggled() && target != null) {
            Utils.HUD.re(new BlockPos(
                    (int) Math.floor(target.posX),
                    (int) Math.floor(target.posY),
                    (int) Math.floor(target.posZ)),
                    0xFFFF0000, true);
        }

        if (renderPredicted.isToggled() && hasVel) {
            Utils.HUD.re(new BlockPos(
                    (int) Math.floor(predX),
                    (int) Math.floor(AutoBlockHelper.predictY(target, predictionTicks.getInput())),
                    (int) Math.floor(predZ)),
                    0xFF00FF00, true);
        }

        if (renderBlocks.isToggled()) {
            for (int i = 0; i < 3; i++) {
                if (wallPos[i] == null)
                    continue;
                int c;
                switch (result[i] != null ? result[i] : WallResult.WAITING) {
                    case CONFIRMED:    c = 0xFF00FF00; break;
                    case WAITING:      c = 0xFFFFFF00; break;
                    case FAILED:       c = 0xFFFF0000; break;
                    case NO_SUPPORT:   c = 0xFFFF8800; break;
                    case OUT_OF_REACH: c = 0xFFFF0000; break;
                    default:           c = 0x80FFFFFF;
                }
                Utils.HUD.re(wallPos[i], c, true);
            }
        }
    }

    private void renderPreview() {
        float lineWidth = (float) previewLineWidth.getInput();
        float alpha = (float) previewAlpha.getInput();

        for (int i = 0; i < 3; i++) {
            if (wallPos[i] == null || result[i] == null)
                continue;
            if (result[i] == WallResult.FAILED || result[i] == WallResult.OUT_OF_REACH)
                continue;
            if (result[i] == WallResult.CONFIRMED && !renderConfirmed.isToggled())
                continue;

            int color;
            float a;
            if (i == blockIdx && result[i] == WallResult.WAITING) {
                color = 0xFFFF0000;
                a = alpha;
            } else if (result[i] == WallResult.CONFIRMED) {
                color = 0xFF00FF00;
                a = alpha * 0.6F;
            } else {
                color = 0xFFFFFFFF;
                a = alpha * 0.3F;
            }

            drawBlockOutline(wallPos[i], color, a, lineWidth);
        }
    }

    private void drawBlockOutline(BlockPos pos, int color, float alpha, float lineWidth) {
        float r = (float) ((color >> 16) & 255) / 255.0F;
        float g = (float) ((color >> 8) & 255) / 255.0F;
        float b = (float) (color & 255) / 255.0F;

        double rx = pos.getX() - mc.getRenderManager().viewerPosX;
        double ry = pos.getY() - mc.getRenderManager().viewerPosY;
        double rz = pos.getZ() - mc.getRenderManager().viewerPosZ;

        AxisAlignedBB bb = new AxisAlignedBB(rx, ry, rz, rx + 1, ry + 1, rz + 1);

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(true);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glLineWidth(lineWidth);
        GL11.glColor4f(r, g, b, alpha);
        RenderGlobal.drawSelectionBoundingBox(bb);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    // ========================= INNER TYPE =========================

    private enum WallResult {
        WAITING, CONFIRMED, FAILED, NO_SUPPORT, OUT_OF_REACH
    }
}
