package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.LookEvent;
import keystrokesmod.client.event.impl.Render2DEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import org.lwjgl.opengl.GL11;

/**
 * Predictive 3-block horizontal wall placement across a moving target's path.
 *
 * ROTATION ARCHITECTURE (matches Ravn's existing pipeline):
 *
 *   UpdateEvent PRE  →  e.setYaw()/setPitch()        →  C03 packet (server)
 *                    →  renderYawOffset/yawHead       →  player model
 *                    →  rotationYaw/pitch              →  direct field write
 *
 *   LookEvent        →  e.setYaw()/setPitch()          →  camera look direction
 *
 * Both layers must be set every tick while rotating.
 * If only UpdateEvent is set, the camera does NOT move (LookEvent controls it).
 * If only LookEvent is set, the server gets stale rotation.
 */
public class AutoBlock extends Module {

    // ========================= SETTINGS =========================

    public static SliderSetting range;
    public static SliderSetting predictionTicks;
    public static SliderSetting placementReach;
    public static SliderSetting wallSpacing;
    public static SliderSetting frontDistance;
    public static SliderSetting tickDelay;
    public static SliderSetting confirmDelay;
    public static SliderSetting maxRetries;
    public static SliderSetting rotationSpeed;
    public static SliderSetting rotationTolerance;
    public static TickSetting predictiveRotation;
    public static TickSetting debug;
    public static TickSetting renderTarget;
    public static TickSetting renderPredicted;
    public static TickSetting renderBlocks;
    public static TickSetting blockPreview;
    public static SliderSetting previewLineWidth;
    public static SliderSetting previewAlpha;
    public static TickSetting renderConfirmed;

    // ========================= STATE MACHINE =========================

    private static final int S_IDLE = 0;
    private static final int S_ACQUIRING = 1;
    private static final int S_COMPUTING = 2;
    private static final int S_ROTATING = 3;
    private static final int S_PLACING = 4;
    private static final int S_CONFIRMING = 5;
    private static final int S_COMPLETE = 6;

    private int state;
    private int tickAccum;
    private int confirmAccum;
    private int retryAccum;
    private int acquireTicks;
    private int completeTicks;

    // ========================= ROTATION =========================
    //
    // Unified rotation state. Both UpdateEvent and LookEvent read from
    // these fields. This is the SINGLE source of truth for camera direction.
    //
    private float desiredYaw, desiredPitch;
    private float appliedYaw, appliedPitch;
    private float prevAppliedYaw, prevAppliedPitch;
    private boolean hasApplied;
    private boolean rotationReached;

    // ========================= PLACEMENT PLAN =========================
    // Single source of truth for preview, rotation, validation, and placement.

    private int blockIdx;
    private final BlockPos[] wallPos = new BlockPos[3];
    private final BlockPos[] supportPos = new BlockPos[3];
    private final EnumFacing[] face = new EnumFacing[3];
    private final Vec3[] hitVec = new Vec3[3];
    private final WallResult[] result = new WallResult[3];
    private Block expectedBlock;

    // ========================= TARGET / PREDICTION =========================

    private EntityPlayer target;
    private double prevTX, prevTZ;
    private double velX, velZ;
    private boolean hasVel;
    private double predX, predZ, predYaw;

    // ========================= STALE =========================

    private double stalePlayerX, stalePlayerZ;
    private double staleVelX, staleVelZ;

    // ========================= INVENTORY =========================

    private int savedSlot = -1;
    private int blockSlot = -1;

    // ========================= CONFIRMATION =========================

    private long placementStartTick;
    private Block placementExpectedBlock;
    private static final long PLACEMENT_TIMEOUT_TICKS = 20;

    // ========================= GCD =========================

    private double getMouseGCD() {
        final float sens = mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
        final float pow = sens * sens * sens * 8.0F;
        return pow * 0.15D;
    }

    private float applyGCD(float yaw, float prevYaw) {
        double gcd = getMouseGCD();
        float dif = yaw - prevYaw;
        return yaw - (float)(dif % gcd);
    }

    // ========================= CONSTRUCTOR =========================

    public AutoBlock() {
        super("AutoBlock", ModuleCategory.player);
        this.registerSetting(new DescriptionSetting(
                "Predictive 3-block horizontal wall placement across a moving target's path."));
        this.registerSetting(range = new SliderSetting("Target range", 20.0D, 4.0D, 40.0D, 1.0D));
        this.registerSetting(predictionTicks = new SliderSetting("Prediction ticks", 10.0D, 1.0D, 40.0D, 1.0D));
        this.registerSetting(placementReach = new SliderSetting("Reach buffer", 0.0D, 0.0D, 1.0D, 0.1D));
        this.registerSetting(wallSpacing = new SliderSetting("Wall spacing", 1.0D, 0.5D, 3.0D, 0.5D));
        this.registerSetting(frontDistance = new SliderSetting("Front distance", 1.5D, 1.0D, 5.0D, 0.5D));
        this.registerSetting(tickDelay = new SliderSetting("Tick delay", 1.0D, 0.0D, 4.0D, 1.0D));
        this.registerSetting(confirmDelay = new SliderSetting("Confirm ticks", 3.0D, 1.0D, 10.0D, 1.0D));
        this.registerSetting(maxRetries = new SliderSetting("Max retries", 2.0D, 0.0D, 5.0D, 1.0D));
        this.registerSetting(rotationSpeed = new SliderSetting("Rotation speed", 40.0D, 5.0D, 180.0D, 1.0D));
        this.registerSetting(rotationTolerance = new SliderSetting("Rotation tolerance", 2.0D, 0.5D, 10.0D, 0.5D));
        this.registerSetting(predictiveRotation = new TickSetting("Predictive rotation", true));
        this.registerSetting(debug = new TickSetting("Debug", false));
        this.registerSetting(renderTarget = new TickSetting("Render target", true));
        this.registerSetting(renderPredicted = new TickSetting("Render predicted", true));
        this.registerSetting(renderBlocks = new TickSetting("Render blocks", true));
        this.registerSetting(blockPreview = new TickSetting("Block preview", true));
        this.registerSetting(previewLineWidth = new SliderSetting("Preview line width", 2.0D, 1.0D, 5.0D, 0.5D));
        this.registerSetting(previewAlpha = new SliderSetting("Preview alpha", 1.0D, 0.1D, 1.0D, 0.1D));
        this.registerSetting(renderConfirmed = new TickSetting("Render confirmed", false));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        reset();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        restoreSlot();
        reset();
    }

    private boolean isActive() {
        return state >= S_ROTATING && state <= S_CONFIRMING;
    }

    // ========================= TICK =========================

    @Subscribe
    public void onTick(TickEvent e) {
        if (!Utils.Player.isPlayerInGame() || mc.thePlayer == null || mc.theWorld == null)
            return;
        if (mc.currentScreen != null)
            return;

        if (state > S_IDLE && state < S_COMPLETE && !targetValid()) {
            debugMsg("\u00a7cTarget lost");
            restoreSlot();
            reset();
            return;
        }

        tickAccum++;
        if (tickAccum < (int) tickDelay.getInput())
            return;
        tickAccum = 0;

        switch (state) {
            case S_IDLE:      tickIdle(); break;
            case S_ACQUIRING: tickAcquiring(); break;
            case S_COMPUTING: tickComputing(); break;
            case S_ROTATING:  tickRotating(); break;
            case S_PLACING:   tickPlacing(); break;
            case S_CONFIRMING:tickConfirming(); break;
            case S_COMPLETE:  tickComplete(); break;
        }
    }

    private void tickIdle() {
        EntityPlayer found = AutoBlockHelper.findTarget(range.getInput());
        if (found == null) { target = null; hasVel = false; return; }
        if (found != target) { target = found; hasVel = false; acquireTicks = 0; }
        state = S_ACQUIRING;
    }

    private void tickAcquiring() {
        if (!targetValid()) { restoreSlot(); reset(); return; }
        if (hasVel) {
            double[] v = AutoBlockHelper.calcVelocity(target, prevTX, prevTZ);
            velX = v[0]; velZ = v[1];
        }
        prevTX = target.posX; prevTZ = target.posZ;
        hasVel = true;
        acquireTicks++;
        if (acquireTicks >= 2 && AutoBlockHelper.isMoving(velX, velZ, 0.01D))
            state = S_COMPUTING;
    }

    private void tickComputing() {
        double ticks = predictionTicks.getInput();
        predX = AutoBlockHelper.predictX(target.posX, velX, ticks);
        predZ = AutoBlockHelper.predictZ(target.posZ, velZ, ticks);
        int wallY = (int) Math.floor(AutoBlockHelper.predictY(target, ticks));
        predYaw = AutoBlockHelper.directionDegrees(velX, velZ);

        BlockPos predCenter = new BlockPos((int) Math.floor(predX), wallY, (int) Math.floor(predZ));
        if (!isWithinActualReach(predCenter)) {
            debugMsg("\u00a7cPrediction out of reach"); restoreSlot(); reset(); return;
        }

        BlockPos[] w = AutoBlockHelper.calcWall(predX, predZ, wallY, velX, velZ,
                wallSpacing.getInput(), frontDistance.getInput());
        if (w == null) { debugMsg("\u00a7cWall computation failed"); restoreSlot(); reset(); return; }

        if (savedSlot == -1) savedSlot = mc.thePlayer.inventory.currentItem;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) {
            blockSlot = AutoBlockHelper.findBlockInHotbar();
            if (blockSlot == -1) { debugMsg("\u00a7cNo block in hotbar"); restoreSlot(); reset(); return; }
            mc.thePlayer.inventory.currentItem = blockSlot;
            held = mc.thePlayer.getHeldItem();
        } else {
            blockSlot = mc.thePlayer.inventory.currentItem;
        }

        if (held == null || !(held.getItem() instanceof ItemBlock)) {
            debugMsg("\u00a7cNo block available"); restoreSlot(); reset(); return;
        }

        expectedBlock = ((ItemBlock) held.getItem()).block;

        for (int i = 0; i < 3; i++) {
            wallPos[i] = w[i];
            result[i] = WallResult.WAITING;
            supportPos[i] = null; face[i] = null; hitVec[i] = null;

            if (!AutoBlockHelper.isChunkLoaded(wallPos[i])) { result[i] = WallResult.FAILED; continue; }
            if (!AutoBlockHelper.isBlockReplaceable(wallPos[i])) { result[i] = WallResult.FAILED; continue; }

            supportPos[i] = AutoBlockHelper.findSupportBlock(wallPos[i]);
            if (supportPos[i] == null) { result[i] = WallResult.NO_SUPPORT; continue; }

            face[i] = AutoBlockHelper.findPlacementFace(wallPos[i], supportPos[i]);
            if (face[i] == null) { result[i] = WallResult.NO_SUPPORT; continue; }

            hitVec[i] = AutoBlockHelper.computeHitVec(supportPos[i], face[i]);
        }

        stalePlayerX = mc.thePlayer.posX; stalePlayerZ = mc.thePlayer.posZ;
        staleVelX = velX; staleVelZ = velZ;

        blockIdx = nextWaiting(-1);
        if (blockIdx == -1) { debugMsg("\u00a7cNo blocks to place"); restoreSlot(); reset(); return; }

        computeRotation(blockIdx);
        state = S_ROTATING;
        confirmAccum = 0;
        retryAccum = 0;
    }

    private void tickRotating() {
        if (isWallStale()) {
            debugMsg("\u00a7eWall stale, recomputing");
            restoreSlot(); state = S_COMPUTING; savedSlot = -1; return;
        }

        if (!rotationReached) {
            confirmAccum++;
            if (confirmAccum > 40) {
                debugMsg("\u00a7cRotation timeout"); result[blockIdx] = WallResult.FAILED; advance();
            }
            return;
        }

        if (!validatePlacement(blockIdx)) {
            debugMsg("\u00a7cPre-place validation failed, re-aiming");
            computeRotation(blockIdx);
            return;
        }

        if (mc.thePlayer.inventory.currentItem != blockSlot)
            mc.thePlayer.inventory.currentItem = blockSlot;

        state = S_PLACING;
    }

    private void tickPlacing() {
        if (!holdBlock()) { result[blockIdx] = WallResult.FAILED; advance(); return; }
        if (supportPos[blockIdx] == null) { result[blockIdx] = WallResult.NO_SUPPORT; advance(); return; }

        boolean placed = doPlace(wallPos[blockIdx], supportPos[blockIdx], face[blockIdx], hitVec[blockIdx]);
        if (placed) {
            placementStartTick = mc.thePlayer.ticksExisted;
            placementExpectedBlock = expectedBlock;
            debugMsg("\u00a7aBlock " + (blockIdx + 1) + " sent");
            state = S_CONFIRMING;
            confirmAccum = 0;
        } else {
            retryAccum++;
            if (retryAccum >= (int) maxRetries.getInput()) {
                result[blockIdx] = WallResult.FAILED; advance();
            } else {
                computeRotation(blockIdx);
                state = S_ROTATING;
            }
        }
    }

    private void tickConfirming() {
        confirmAccum++;
        Block actual = mc.theWorld.getBlockState(wallPos[blockIdx]).getBlock();
        if (actual == expectedBlock) {
            result[blockIdx] = WallResult.CONFIRMED;
            debugMsg("\u00a7aBlock " + (blockIdx + 1) + " confirmed");
            advance(); return;
        }
        long elapsed = mc.thePlayer.ticksExisted - placementStartTick;
        if (elapsed > PLACEMENT_TIMEOUT_TICKS || confirmAccum >= (int) confirmDelay.getInput()) {
            result[blockIdx] = WallResult.FAILED;
            debugMsg("\u00a7cBlock " + (blockIdx + 1) + " confirm timeout");
            advance();
        }
    }

    private void tickComplete() {
        completeTicks++;
        if (completeTicks > 5) { restoreSlot(); reset(); }
    }

    // ========================= ROTATION CONTROLLER =========================
    //
    // This is the SINGLE rotation controller. It sets BOTH layers:
    //   1. UpdateEvent (packet + model + direct field)
    //   2. LookEvent (camera look direction)
    //
    // Both are set EVERY tick while isActive().
    // The LookEvent handler runs during camera rendering and MUST have
    // current applied values available.
    //
    // This matches exactly how KillAura controls rotation in Ravn:
    //   - KillAura sets e.setYaw() + renderYawOffset + rotationYawHead in UpdateEvent
    //   - KillAura overrides LookEvent with target yaw/pitch
    //   - KillAura does NOT write mc.thePlayer.rotationYaw directly
    //   - The camera moves because LookEvent controls it

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!e.isPre() || mc.thePlayer == null)
            return;

        if (!isActive()) return;

        float speed = (float) rotationSpeed.getInput();
        float tolerance = (float) rotationTolerance.getInput();

        float curYaw = mc.thePlayer.rotationYaw;
        float curPitch = mc.thePlayer.rotationPitch;

        float dYaw = MathHelper.wrapAngleTo180_float(desiredYaw - curYaw);
        float dPitch = desiredPitch - curPitch;

        float newYaw = curYaw + MathHelper.clamp_float(dYaw, -speed, speed);
        float newPitch = MathHelper.clamp_float(
                curPitch + MathHelper.clamp_float(dPitch, -speed, speed),
                -90.0F, 90.0F);

        float prevYaw = hasApplied ? prevAppliedYaw : curYaw;
        float prevPitch = hasApplied ? prevAppliedPitch : curPitch;

        newYaw = maxAngleChange(prevYaw, newYaw, speed);
        newPitch = maxAngleChange(prevPitch, newPitch, speed);

        newYaw = applyGCD(newYaw, prevYaw);
        newPitch = applyGCD(newPitch, prevPitch);

        appliedYaw = newYaw;
        appliedPitch = newPitch;
        prevAppliedYaw = newYaw;
        prevAppliedPitch = newPitch;
        hasApplied = true;

        e.setYaw(appliedYaw);
        e.setPitch(appliedPitch);

        mc.thePlayer.renderYawOffset = appliedYaw;
        mc.thePlayer.rotationYawHead = appliedYaw;

        float errYaw = Math.abs(MathHelper.wrapAngleTo180_float(desiredYaw - appliedYaw));
        float errPitch = Math.abs(desiredPitch - appliedPitch);
        if (errYaw <= tolerance && errPitch <= tolerance) {
            if (!rotationReached) {
                rotationReached = true;
                debugMsg("\u00a7aRotation reached (err=" + String.format("%.2f", errYaw) + "," + String.format("%.2f", errPitch) + ")");
            }
        }
    }

    @Subscribe
    public void onLookEvent(LookEvent e) {
        if (mc.thePlayer == null) return;
        if (!isActive()) return;
        if (!hasApplied) return;

        e.setPrevYaw(prevAppliedYaw);
        e.setPrevPitch(prevAppliedPitch);
        e.setYaw(appliedYaw);
        e.setPitch(appliedPitch);
    }

    // ========================= REACH =========================

    private double getActualReach() {
        return mc.playerController.getBlockReachDistance() + placementReach.getInput();
    }

    private boolean isWithinActualReach(BlockPos pos) {
        if (mc.thePlayer == null) return false;
        double dx = pos.getX() + 0.5 - mc.thePlayer.posX;
        double dy = pos.getY() + 0.5 - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = pos.getZ() + 0.5 - mc.thePlayer.posZ;
        return Math.sqrt(dx * dx + dy * dy + dz * dz) <= getActualReach();
    }

    // ========================= PLACEMENT VALIDATION =========================

    private boolean validatePlacement(int i) {
        if (i < 0 || i >= 3) return false;
        if (wallPos[i] == null || supportPos[i] == null || face[i] == null || hitVec[i] == null) return false;
        if (!AutoBlockHelper.isBlockReplaceable(wallPos[i])) return false;
        if (!AutoBlockHelper.isChunkLoaded(wallPos[i])) return false;
        if (!isWithinActualReach(wallPos[i])) return false;
        if (!holdBlock()) return false;
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) return false;
        if (((ItemBlock) held.getItem()).block != expectedBlock) return false;

        Block sb = mc.theWorld.getBlockState(supportPos[i]).getBlock();
        if (!sb.isNormalCube() && !sb.isFullBlock()) return false;

        Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
        MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(eye, hitVec[i], false, false, true);
        if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) return false;
        if (!mop.getBlockPos().equals(supportPos[i])) return false;
        if (mop.sideHit != face[i]) return false;

        EnumFacing curFace = AutoBlockHelper.findPlacementFace(wallPos[i], supportPos[i]);
        if (curFace == null || curFace != face[i]) return false;

        return true;
    }

    // ========================= STALE WALL =========================

    private boolean isWallStale() {
        if (mc.thePlayer == null || target == null) return true;
        double pd = Math.sqrt(
                (mc.thePlayer.posX - stalePlayerX) * (mc.thePlayer.posX - stalePlayerX) +
                (mc.thePlayer.posZ - stalePlayerZ) * (mc.thePlayer.posZ - stalePlayerZ));
        if (pd > 2.0) return true;
        if (AutoBlockHelper.isMoving(velX, velZ, 0.01D) && AutoBlockHelper.isMoving(staleVelX, staleVelZ, 0.01D)) {
            double a = Math.abs(Math.toDegrees(Math.atan2(velX, velZ) - Math.atan2(staleVelX, staleVelZ)));
            if (a > 180) a = 360 - a;
            if (a > 30) return true;
        }
        for (int i = 0; i < 3; i++)
            if (result[i] == WallResult.WAITING && wallPos[i] != null)
                if (!AutoBlockHelper.isChunkLoaded(wallPos[i]) || !AutoBlockHelper.isBlockReplaceable(wallPos[i]))
                    return true;
        return false;
    }

    // ========================= STATE ADVANCEMENT =========================

    private void advance() {
        retryAccum = 0;
        int next = nextWaiting(blockIdx + 1);
        if (next != -1) {
            blockIdx = next;
            if (mc.thePlayer != null && blockSlot >= 0 && blockSlot < 9)
                mc.thePlayer.inventory.currentItem = blockSlot;
            computeRotation(blockIdx);
            state = S_ROTATING;
            confirmAccum = 0;
        } else {
            state = S_COMPLETE;
            completeTicks = 0;
        }
    }

    private int nextWaiting(int from) {
        for (int i = from; i < 3; i++)
            if (result[i] == WallResult.WAITING) return i;
        return -1;
    }

    // ========================= BLOCK PLACEMENT =========================

    private boolean doPlace(BlockPos target, BlockPos support, EnumFacing f, Vec3 hv) {
        if (mc.thePlayer == null || mc.theWorld == null) return false;
        if (!AutoBlockHelper.isBlockReplaceable(target)) return false;
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) return false;
        boolean placed = mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, held, support, f, hv);
        if (placed) {
            mc.thePlayer.swingItem();
            mc.getItemRenderer().resetEquippedProgress();
        }
        return placed;
    }

    private boolean holdBlock() {
        if (mc.thePlayer.inventory.currentItem != blockSlot) {
            mc.thePlayer.inventory.currentItem = blockSlot;
        }
        ItemStack held = mc.thePlayer.getHeldItem();
        return held != null && held.getItem() instanceof ItemBlock
                && ((ItemBlock) held.getItem()).block == expectedBlock;
    }

    private void computeRotation(int index) {
        if (hitVec[index] == null) { result[index] = WallResult.FAILED; advance(); return; }
        float[] r = AutoBlockHelper.calcRotation(hitVec[index]);
        desiredYaw = r[0];
        desiredPitch = r[1];
        rotationReached = false;
        hasApplied = false;
        confirmAccum = 0;
    }

    private boolean targetValid() {
        return target != null && !target.isDead && target.getHealth() > 0
                && mc.theWorld != null && mc.theWorld.getEntityByID(target.getEntityId()) != null;
    }

    private float maxAngleChange(float prev, float target, float maxTurn) {
        float dif = MathHelper.wrapAngleTo180_float(target - prev);
        if (dif > maxTurn) dif = maxTurn;
        if (dif < -maxTurn) dif = -maxTurn;
        return prev + dif;
    }

    // ========================= INVENTORY =========================

    private void restoreSlot() {
        if (savedSlot >= 0 && savedSlot < 9 && mc.thePlayer != null)
            mc.thePlayer.inventory.currentItem = savedSlot;
        savedSlot = -1; blockSlot = -1;
    }

    // ========================= RESET =========================

    private void reset() {
        state = S_IDLE;
        target = null; hasVel = false; velX = velZ = 0;
        rotationReached = false; hasApplied = false;
        tickAccum = confirmAccum = retryAccum = acquireTicks = completeTicks = 0;
        blockIdx = -1; expectedBlock = null;
        for (int i = 0; i < 3; i++) {
            wallPos[i] = supportPos[i] = null;
            face[i] = null; hitVec[i] = null; result[i] = null;
        }
    }

    // ========================= DEBUG =========================

    private void debugMsg(String msg) {
        if (debug.isToggled())
            Utils.Player.sendMessageToSelf("[AB] " + msg);
    }

    @Subscribe
    public void onRender2D(Render2DEvent e) {
        if (!debug.isToggled() || !Utils.Player.isPlayerInGame()) return;

        int y = 50;
        draw(y, "\u00a7dAutoBlock", 0xFFFFFF); y += 12;

        if (target != null) {
            draw(y, "Target", target.getName()); y += 10;
            draw(y, "Distance", String.format("%.1f", mc.thePlayer.getDistanceToEntity(target))); y += 10;
            draw(y, "Velocity", String.format("%.3f, %.3f", velX, velZ)); y += 10;
            draw(y, "Direction", AutoBlockHelper.isMoving(velX, velZ, 0.01D)
                    ? AutoBlockHelper.directionName(velX, velZ) : "STATIC"); y += 10;
            draw(y, "Pred X/Z", String.format("%.2f / %.2f", predX, predZ)); y += 10;
        }

        y += 4;
        draw(y, "State", stateName() + " | Rot: " + (rotationReached ? "DONE" : hasApplied ? "ACTIVE" : "NONE")); y += 10;
        if (blockIdx >= 0) {
            draw(y, "Block", (blockIdx + 1) + "/3"); y += 10;
            if (wallPos[blockIdx] != null)
                draw(y, "Pos", wallPos[blockIdx].getX() + "," + wallPos[blockIdx].getY() + "," + wallPos[blockIdx].getZ()); y += 10;
            if (supportPos[blockIdx] != null)
                draw(y, "Support", supportPos[blockIdx].getX() + "," + supportPos[blockIdx].getY() + "," + supportPos[blockIdx].getZ()); y += 10;
            if (face[blockIdx] != null) draw(y, "Face", face[blockIdx].getName()); y += 10;
            if (hitVec[blockIdx] != null)
                draw(y, "HitVec", String.format("%.2f,%.2f,%.2f", hitVec[blockIdx].xCoord, hitVec[blockIdx].yCoord, hitVec[blockIdx].zCoord)); y += 10;
        }
        y += 4;

        draw(y, "Des Yaw", String.format("%.2f", desiredYaw)); y += 10;
        draw(y, "Des Pitch", String.format("%.2f", desiredPitch)); y += 10;
        draw(y, "Applied Yaw", String.format("%.2f", appliedYaw)); y += 10;
        draw(y, "Applied Pitch", String.format("%.2f", appliedPitch)); y += 10;
        draw(y, "Player Yaw", String.format("%.2f", mc.thePlayer.rotationYaw)); y += 10;
        draw(y, "Player Pitch", String.format("%.2f", mc.thePlayer.rotationPitch)); y += 10;
        y += 4;

        float errYaw = Math.abs(MathHelper.wrapAngleTo180_float(desiredYaw - mc.thePlayer.rotationYaw));
        float errPitch = Math.abs(desiredPitch - mc.thePlayer.rotationPitch);
        draw(y, "Err Yaw/Pitch", String.format("%.2f / %.2f", errYaw, errPitch)); y += 10;
        draw(y, "RotationSync", errYaw < 5.0F ? "\u00a7aOK" : "\u00a7cDESYNC"); y += 10;
        y += 4;

        boolean los = validateLineOfSightSafe();
        boolean reach = blockIdx >= 0 && blockIdx < 3 && wallPos[blockIdx] != null
                && isWithinActualReach(wallPos[blockIdx]);
        draw(y, "LOS", los ? "\u00a7aYES" : "\u00a7cNO"); y += 10;
        draw(y, "Reach", reach ? "\u00a7aYES" : "\u00a7cNO"); y += 10;
        draw(y, "Held", holdBlock() ? "\u00a7aYES" : "\u00a7cNO"); y += 10;
        y += 4;

        String[] names = {"LEFT", "CENTER", "RIGHT"};
        for (int i = 0; i < 3; i++) {
            String s; int c;
            if (result[i] == null) { s = "\u00a77N/A"; c = 0x808080; }
            else switch (result[i]) {
                case CONFIRMED:    s = "\u00a7aCONFIRMED";  c = 0x55FF55; break;
                case WAITING:      s = "\u00a7eWAITING";    c = 0xFFFF55; break;
                case NO_SUPPORT:   s = "\u00a7cNO_SUPPORT"; c = 0xFF5555; break;
                case FAILED:       s = "\u00a7cFAILED";     c = 0xFF5555; break;
                case OUT_OF_REACH: s = "\u00a7cOOR";        c = 0xFF5555; break;
                default:           s = "\u00a77" + result[i].name(); c = 0xAAAAAA;
            }
            mc.fontRendererObj.drawStringWithShadow("  \u00a77" + names[i] + ": " + s, 4, y, c);
            y += 10;
        }
    }

    private boolean validateLineOfSightSafe() {
        if (blockIdx < 0 || blockIdx >= 3 || hitVec[blockIdx] == null || supportPos[blockIdx] == null) return false;
        Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
        MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(eye, hitVec[blockIdx], false, false, true);
        return mop != null && mop.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK
                && mop.getBlockPos().equals(supportPos[blockIdx]) && mop.sideHit == face[blockIdx];
    }

    private void draw(int y, String label, String value) {
        mc.fontRendererObj.drawStringWithShadow("\u00a77" + label + ": \u00a7f" + value, 4, y, 0xFFFFFF);
    }

    private String stateName() {
        switch (state) {
            case S_IDLE:       return "IDLE";
            case S_ACQUIRING:  return "ACQUIRING";
            case S_COMPUTING:  return "COMPUTING";
            case S_ROTATING:   return "ROTATING";
            case S_PLACING:    return "PLACING";
            case S_CONFIRMING: return "CONFIRMING";
            case S_COMPLETE:   return "COMPLETE";
            default:           return "?";
        }
    }

    // ========================= WORLD RENDERING =========================

    @Subscribe
    public void onRenderWorldLast(ForgeEvent fe) {
        if (!(fe.getEvent() instanceof RenderWorldLastEvent)) return;
        if (!Utils.Player.isPlayerInGame() || mc.thePlayer == null) return;

        if (debug.isToggled()) renderDebugWorld();
        if (blockPreview.isToggled() && isActive()) renderPreview();
    }

    private void renderDebugWorld() {
        if (renderTarget.isToggled() && target != null)
            Utils.HUD.re(new BlockPos((int) Math.floor(target.posX), (int) Math.floor(target.posY),
                    (int) Math.floor(target.posZ)), 0xFFFF0000, true);
        if (renderPredicted.isToggled() && hasVel)
            Utils.HUD.re(new BlockPos((int) Math.floor(predX),
                    (int) Math.floor(AutoBlockHelper.predictY(target, predictionTicks.getInput())),
                    (int) Math.floor(predZ)), 0xFF00FF00, true);
        if (renderBlocks.isToggled()) {
            for (int i = 0; i < 3; i++) {
                if (wallPos[i] == null) continue;
                int c;
                switch (result[i] != null ? result[i] : WallResult.WAITING) {
                    case CONFIRMED: c = 0xFF00FF00; break;
                    case WAITING:   c = 0xFFFFFF00; break;
                    default:        c = 0xFFFF0000; break;
                }
                Utils.HUD.re(wallPos[i], c, true);
            }
        }
    }

    private void renderPreview() {
        float lw = (float) previewLineWidth.getInput();
        float alpha = (float) previewAlpha.getInput();

        for (int i = 0; i < 3; i++) {
            if (wallPos[i] == null || result[i] == null) continue;
            if (result[i] == WallResult.FAILED || result[i] == WallResult.OUT_OF_REACH) continue;
            if (result[i] == WallResult.CONFIRMED && !renderConfirmed.isToggled()) continue;

            int color; float a;
            if (i == blockIdx && result[i] == WallResult.WAITING) { color = 0xFFFF0000; a = alpha; }
            else if (result[i] == WallResult.CONFIRMED) { color = 0xFF00FF00; a = alpha * 0.6F; }
            else { color = 0xFFFFFFFF; a = alpha * 0.3F; }

            drawBlockOutline(wallPos[i], color, a, lw);
        }
    }

    private void drawBlockOutline(BlockPos pos, int color, float alpha, float lw) {
        float r = (float) ((color >> 16) & 255) / 255.0F;
        float g = (float) ((color >> 8) & 255) / 255.0F;
        float b = (float) (color & 255) / 255.0F;
        double rx = pos.getX() - mc.getRenderManager().viewerPosX;
        double ry = pos.getY() - mc.getRenderManager().viewerPosY;
        double rz = pos.getZ() - mc.getRenderManager().viewerPosZ;
        AxisAlignedBB bb = new AxisAlignedBB(rx, ry, rz, rx + 1, ry + 1, rz + 1);

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(true);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glLineWidth(lw);
        GL11.glColor4f(r, g, b, alpha);
        RenderGlobal.drawSelectionBoundingBox(bb);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    private enum WallResult {
        WAITING, CONFIRMED, FAILED, NO_SUPPORT, OUT_OF_REACH
    }
}
