package keystrokesmod.client.module.modules.other;

import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

public class Animations extends Module {

    // ========================= 1.7 ITEM POSITIONS =========================

    public static TickSetting firstPersonItemPositions;
    public static TickSetting thirdPersonItemPositions;
    public static TickSetting oldArmPosition;
    public static TickSetting thirdPersonBlock;
    public static TickSetting firstPersonFishingRodPosition;
    public static TickSetting thirdPersonFishingRodPosition;
    public static TickSetting fishingRodStickCastTexture;
    public static TickSetting oldItemRotations;

    // ========================= BLOCK-HITTING / INTERACTION =========================

    public static TickSetting oldBlockhitting;
    public static TickSetting usagePunching;
    public static TickSetting usagePunchingParticles;
    public static TickSetting fakeMissPenaltySwing;
    public static TickSetting fakeMissPenaltyParticles;
    public static TickSetting fakeBlockHit;
    public static TickSetting modernDropSwing;
    public static TickSetting funnyFidget;

    // ========================= SWING =========================

    public static SliderSetting swingSpeed;

    // ========================= RE-EQUIP =========================

    public static SliderSetting reequipSpeed;
    public static TickSetting fixReequip;
    public static ComboSetting<ItemSwitchMode> itemSwitchMode;

    // ========================= CUSTOM POSITIONS =========================

    public static TickSetting globalPositions;
    public static SliderSetting itemPositionX;
    public static SliderSetting itemPositionY;
    public static SliderSetting itemPositionZ;
    public static SliderSetting itemRotationPitch;
    public static SliderSetting itemRotationYaw;
    public static SliderSetting itemRotationRoll;
    public static SliderSetting itemScale;
    public static ComboSetting<SwingSetting> swingSetting;

    // ========================= ADVANCED POSITIONS =========================

    public static SliderSetting blockedPositionX;
    public static SliderSetting blockedPositionY;
    public static SliderSetting blockedPositionZ;
    public static SliderSetting blockedRotationPitch;
    public static SliderSetting blockedRotationYaw;
    public static SliderSetting blockedRotationRoll;
    public static SliderSetting blockedScale;

    public static SliderSetting consumePositionX;
    public static SliderSetting consumePositionY;
    public static SliderSetting consumePositionZ;
    public static SliderSetting consumeRotationPitch;
    public static SliderSetting consumeRotationYaw;
    public static SliderSetting consumeRotationRoll;
    public static SliderSetting consumeScale;
    public static SliderSetting consumeIntensity;
    public static SliderSetting consumeSpeed;
    public static TickSetting shouldScaleEat;

    public static SliderSetting droppedPositionX;
    public static SliderSetting droppedPositionY;
    public static SliderSetting droppedPositionZ;
    public static SliderSetting droppedRotationPitch;
    public static SliderSetting droppedRotationYaw;
    public static SliderSetting droppedRotationRoll;
    public static SliderSetting droppedScale;

    // ========================= LUNAR =========================

    public static TickSetting lunarPositions;
    public static TickSetting lunarBlockhit;

    // ========================= FUN =========================

    public static TickSetting wackyArms;

    private static Animations instance;

    public Animations() {
        super("Animations", ModuleCategory.other);
        instance = this;

        // 1.7 item positions
        this.registerSetting(new DescriptionSetting("1.7-style item animations and positions."));
        this.registerSetting(firstPersonItemPositions = new TickSetting("1.7 first-person positions", true));
        this.registerSetting(thirdPersonItemPositions = new TickSetting("1.7 third-person positions", true));
        this.registerSetting(oldArmPosition = new TickSetting("1.7 third-person arm block", true));
        this.registerSetting(thirdPersonBlock = new TickSetting("1.7 third-person block", true));
        this.registerSetting(firstPersonFishingRodPosition = new TickSetting("1.7 first-person rod", true));
        this.registerSetting(thirdPersonFishingRodPosition = new TickSetting("1.7 third-person rod", true));
        this.registerSetting(fishingRodStickCastTexture = new TickSetting("Rod stick cast texture", false));
        this.registerSetting(oldItemRotations = new TickSetting("Old item rotations", false));

        // block-hitting / interaction
        this.registerSetting(new DescriptionSetting("Block-hitting and swing interaction."));
        this.registerSetting(oldBlockhitting = new TickSetting("1.7 block-hitting", true));
        this.registerSetting(usagePunching = new TickSetting("Usage punching", true));
        this.registerSetting(usagePunchingParticles = new TickSetting("Usage punching particles", true));
        this.registerSetting(fakeMissPenaltySwing = new TickSetting("Miss penalty swing", true));
        this.registerSetting(fakeMissPenaltyParticles = new TickSetting("Miss penalty particles", true));
        this.registerSetting(fakeBlockHit = new TickSetting("Fake block hit", false));
        this.registerSetting(modernDropSwing = new TickSetting("Modern drop swing", true));
        this.registerSetting(funnyFidget = new TickSetting("Funny fidget", false));

        // swing
        this.registerSetting(new DescriptionSetting("Swing speed override."));
        this.registerSetting(swingSpeed = new SliderSetting("Swing speed", 1.0D, 0.1D, 5.0D, 0.1D));

        // re-equip
        this.registerSetting(new DescriptionSetting("Re-equip animation control."));
        this.registerSetting(reequipSpeed = new SliderSetting("Re-equip speed", 0.4D, 0.1D, 1.0D, 0.05D));
        this.registerSetting(fixReequip = new TickSetting("Fix re-equip", true));
        this.registerSetting(itemSwitchMode = new ComboSetting<>("Item switch", ItemSwitchMode.V1_8));

        // custom positions
        this.registerSetting(new DescriptionSetting("Custom first-person item position offsets."));
        this.registerSetting(globalPositions = new TickSetting("Custom positions", false));
        this.registerSetting(itemPositionX = new SliderSetting("Position X", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(itemPositionY = new SliderSetting("Position Y", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(itemPositionZ = new SliderSetting("Position Z", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(itemRotationPitch = new SliderSetting("Rotation Pitch", 0.0D, -180.0D, 180.0D, 1.0D));
        this.registerSetting(itemRotationYaw = new SliderSetting("Rotation Yaw", 0.0D, -180.0D, 180.0D, 1.0D));
        this.registerSetting(itemRotationRoll = new SliderSetting("Rotation Roll", 0.0D, -180.0D, 180.0D, 1.0D));
        this.registerSetting(itemScale = new SliderSetting("Scale", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(swingSetting = new ComboSetting<>("Swing mode", SwingSetting.DEFAULT));

        // advanced block/eat/drop positions
        this.registerSetting(new DescriptionSetting("Advanced block position offsets."));
        this.registerSetting(blockedPositionX = new SliderSetting("Block X", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(blockedPositionY = new SliderSetting("Block Y", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(blockedPositionZ = new SliderSetting("Block Z", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(blockedRotationPitch = new SliderSetting("Block Pitch", 0.0D, -180.0D, 180.0D, 1.0D));
        this.registerSetting(blockedRotationYaw = new SliderSetting("Block Yaw", 0.0D, -180.0D, 180.0D, 1.0D));
        this.registerSetting(blockedRotationRoll = new SliderSetting("Block Roll", 0.0D, -180.0D, 180.0D, 1.0D));
        this.registerSetting(blockedScale = new SliderSetting("Block Scale", 0.0D, -1.5D, 1.5D, 0.01D));

        this.registerSetting(new DescriptionSetting("Advanced eating position offsets."));
        this.registerSetting(consumePositionX = new SliderSetting("Eat X", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(consumePositionY = new SliderSetting("Eat Y", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(consumePositionZ = new SliderSetting("Eat Z", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(consumeRotationPitch = new SliderSetting("Eat Pitch", 0.0D, -180.0D, 180.0D, 1.0D));
        this.registerSetting(consumeRotationYaw = new SliderSetting("Eat Yaw", 0.0D, -180.0D, 180.0D, 1.0D));
        this.registerSetting(consumeRotationRoll = new SliderSetting("Eat Roll", 0.0D, -180.0D, 180.0D, 1.0D));
        this.registerSetting(consumeScale = new SliderSetting("Eat Scale", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(consumeIntensity = new SliderSetting("Eat Intensity", 0.0D, -1.0D, 2.0D, 0.01D));
        this.registerSetting(consumeSpeed = new SliderSetting("Eat Speed", 0.0D, -1.0D, 2.0D, 0.01D));
        this.registerSetting(shouldScaleEat = new TickSetting("Scale eat position", false));

        this.registerSetting(new DescriptionSetting("Advanced dropped item position offsets."));
        this.registerSetting(droppedPositionX = new SliderSetting("Drop X", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(droppedPositionY = new SliderSetting("Drop Y", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(droppedPositionZ = new SliderSetting("Drop Z", 0.0D, -1.5D, 1.5D, 0.01D));
        this.registerSetting(droppedRotationPitch = new SliderSetting("Drop Pitch", 0.0D, -180.0D, 180.0D, 1.0D));
        this.registerSetting(droppedRotationYaw = new SliderSetting("Drop Yaw", 0.0D, -180.0D, 180.0D, 1.0D));
        this.registerSetting(droppedRotationRoll = new SliderSetting("Drop Roll", 0.0D, -180.0D, 180.0D, 1.0D));
        this.registerSetting(droppedScale = new SliderSetting("Drop Scale", 0.0D, -1.5D, 1.5D, 0.01D));

        // lunar / fun
        this.registerSetting(new DescriptionSetting("Lunar and fun modes."));
        this.registerSetting(lunarPositions = new TickSetting("Lunar positions", false));
        this.registerSetting(lunarBlockhit = new TickSetting("Lunar block-hit", false));
        this.registerSetting(wackyArms = new TickSetting("Wacky arms", false));
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled();
    }

    public static double getSpeed() {
        return swingSpeed.getInput();
    }

    public static boolean itemAllowed(ItemStack held) {
        return true;
    }

    // ========================= ENUMS =========================

    public enum ItemSwitchMode {
        V1_8("1.8"),
        V1_7("1.7"),
        DISABLED("Disabled");

        private final String name;

        ItemSwitchMode(String n) { this.name = n; }

        @Override
        public String toString() { return name; }
    }

    public enum SwingSetting {
        DEFAULT("Default"),
        SMART_SCALING("Smart Scaling"),
        DISABLE_TRANSLATION("Disable Translation");

        private final String name;

        SwingSetting(String n) { this.name = n; }

        @Override
        public String toString() { return name; }
    }
}
