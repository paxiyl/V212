package keystrokesmod.client.module.modules.other;

import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;

public class Animations extends Module {

    public static SliderSetting swingSpeed;
    public static ComboSetting<ItemFilter> itemFilter;

    private static Animations instance;

    public Animations() {
        super("Animations", ModuleCategory.other);
        instance = this;
        this.registerSetting(new DescriptionSetting("First-person swing speed (client-side only). 1.8.9 renders only the main hand, so this controls the held-item swing."));
        this.registerSetting(swingSpeed = new SliderSetting("Swing speed", 1.0D, 0.1D, 5.0D, 0.1D));
        this.registerSetting(itemFilter = new ComboSetting<>("Item", ItemFilter.ALL));
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled()
                && swingSpeed != null && itemFilter != null;
    }

    public static double getSpeed() {
        return swingSpeed.getInput();
    }

    public static boolean itemAllowed(ItemStack held) {
        ItemFilter f = itemFilter.getMode();
        if (f == ItemFilter.ALL)
            return true;
        if (held == null)
            return false;
        switch (f) {
            case SWORD:
                return held.getItem() instanceof ItemSword;
            case BLOCK:
                return held.getItem() instanceof ItemBlock;
            case TOOL:
                return held.getItem() instanceof ItemTool || held.getItem() instanceof ItemAxe
                        || held.getItem() instanceof ItemPickaxe || held.getItem() instanceof ItemSpade;
            case OTHER:
            default:
                return !(held.getItem() instanceof ItemSword || held.getItem() instanceof ItemBlock
                        || held.getItem() instanceof ItemTool || held.getItem() instanceof ItemAxe
                        || held.getItem() instanceof ItemPickaxe || held.getItem() instanceof ItemSpade);
        }
    }

    public enum ItemFilter {
        ALL("All"),
        SWORD("Sword"),
        BLOCK("Block"),
        TOOL("Tool"),
        OTHER("Other");

        private final String name;

        ItemFilter(String n) {
            this.name = n;
        }

        @Override
        public String toString() {
            return name;
        }
    }
}
