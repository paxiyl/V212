package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DoubleSliderSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemEgg;
import net.minecraft.item.ItemSnowball;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import org.apache.commons.lang3.RandomUtils;

import java.lang.reflect.Field;

public class FastPlace extends Module {
    public static DoubleSliderSetting delaySlider, projSlider;
    public static TickSetting blockOnly, projSeparate;

    public static final Field rightClickDelayTimerField;
    public static final Field blockHitDelayField;

    static {
        rightClickDelayTimerField = ReflectionHelper.findField(Minecraft.class, "field_71467_ac",
                "rightClickDelayTimer");

        if (rightClickDelayTimerField != null) {
            rightClickDelayTimerField.setAccessible(true);
        }

        blockHitDelayField = ReflectionHelper.findField(PlayerControllerMP.class, "field_78778_q", "blockHitDelay");
        if (blockHitDelayField != null) {
            blockHitDelayField.setAccessible(true);
        }
    }

    public FastPlace() {
        super("FastPlace", ModuleCategory.player);

        this.registerSetting(delaySlider = new DoubleSliderSetting("Delay", 1.0D,2.0D, 1.0D, 4.0D, 1.0D));
        this.registerSetting(blockOnly = new TickSetting("Blocks only", true));
        this.registerSetting(projSeparate = new TickSetting("Separate Projectile Delay", true));
        this.registerSetting(projSlider = new DoubleSliderSetting("Projectile Delay", 1.0D,2.0D, 1.0D, 4.0D, 1.0D));

    }

    @Override
    public boolean canBeEnabled() {
        return rightClickDelayTimerField != null;
    }

    @Subscribe
    public void onTick(TickEvent event) {
        if (Utils.Player.isPlayerInGame() && mc.inGameHasFocus && rightClickDelayTimerField != null) {
            if (blockOnly.isToggled()) {
                ItemStack item = mc.thePlayer.getHeldItem();
                if (item != null && (item.getItem() instanceof ItemBlock)) {
                    try {
                        int c = (int) RandomUtils.nextInt((int) delaySlider.getInputMin(), (int) delaySlider.getInputMax());
                        applyDelay(c, 4);
                    } catch (IllegalAccessException | IndexOutOfBoundsException ignored) {
                    }
                } else if (item != null && (item.getItem() instanceof ItemSnowball || item.getItem() instanceof ItemEgg)
                        && projSeparate.isToggled()) {
                    try {
                        int c = (int) RandomUtils.nextInt((int) projSlider.getInputMin(), (int) projSlider.getInputMax());
                        applyDelay(c, 4);
                    } catch (IllegalAccessException | IndexOutOfBoundsException ignored) {
                    }
                }
            } else {
                try {
                    int c = (int) RandomUtils.nextInt((int) delaySlider.getInputMin(), (int) delaySlider.getInputMax());
                    applyDelay(c, 4);
                } catch (IllegalAccessException | IndexOutOfBoundsException ignored) {
                }
            }
        }
    }

    private void applyDelay(int c, int vanillaCooldown) throws IllegalAccessException {
        if (c == 0) {
            rightClickDelayTimerField.set(mc, 0);
            if (blockHitDelayField != null && mc.playerController != null)
                blockHitDelayField.set(mc.playerController, 0);
        } else {
            if (c == vanillaCooldown) {
                return;
            }

            int d = rightClickDelayTimerField.getInt(mc);
            if (d == vanillaCooldown) {
                rightClickDelayTimerField.set(mc, c);
            }

            if (blockHitDelayField != null && mc.playerController != null) {
                int bd = blockHitDelayField.getInt(mc.playerController);
                if (bd == vanillaCooldown) {
                    blockHitDelayField.set(mc.playerController, c);
                }
            }
        }
    }
}
