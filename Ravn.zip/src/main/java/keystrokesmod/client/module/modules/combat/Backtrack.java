package keystrokesmod.client.module.modules.combat;

import com.google.common.eventbus.Subscribe;

import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.GameLoopEvent;
import keystrokesmod.client.event.impl.PacketEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.client.Targets;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.network.play.server.S06PacketUpdateHealth;
import net.minecraft.network.play.server.S07PacketRespawn;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S13PacketDestroyEntities;
import net.minecraft.network.play.server.S14PacketEntity;
import net.minecraft.network.play.server.S18PacketEntityTeleport;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Backtrack - delays the target's position updates so they appear
 * (and stay hittable) slightly behind their real server position.
 * Only movement/velocity packets of the active target are delayed;
 * everything else flows normally to keep the connection safe.
 * Ported from FDPClient's Backtrack for Raven.
 */
public class Backtrack extends Module {

    public static SliderSetting range, delayMin, delayMax;

    private static final int MAX_QUEUE_SIZE = 100;

    private static final class QueuedPacket {
        final Packet<INetHandlerPlayClient> packet;
        final long time;

        QueuedPacket(Packet<INetHandlerPlayClient> packet, long time) {
            this.packet = packet;
            this.time = time;
        }
    }

    private final ConcurrentLinkedQueue<QueuedPacket> queue = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<QueuedPacket> overflow = new ConcurrentLinkedQueue<>();

    private EntityPlayer target;
    private long currentDelay = 100L;

    public Backtrack() {
        super("Backtrack", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Hits enemies where they were, not where they are"));
        this.registerSetting(range = new SliderSetting("Range", 3.5D, 1.0D, 6.0D, 0.5D));
        this.registerSetting(delayMin = new SliderSetting("Delay min (ms)", 60.0D, 0.0D, 500.0D, 10.0D));
        this.registerSetting(delayMax = new SliderSetting("Delay max (ms)", 120.0D, 0.0D, 500.0D, 10.0D));
    }

    @Override
    public void onEnable() {
        armDelay();
    }

    @Override
    public void onDisable() {
        flush();
        target = null;
    }
    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (!(fe.getEvent() instanceof AttackEntityEvent))
            return;

        if (!isEnabled())
            return;

        Entity attacked = ((AttackEntityEvent) fe.getEvent()).target;
        if (!(attacked instanceof EntityPlayer) || attacked == mc.thePlayer)
            return;

        setTarget((EntityPlayer) attacked);
    }

    @Subscribe
    public void onPacket(PacketEvent e) {
        if (!e.isIncoming() || !isEnabled())
            return;

        if (!Utils.Player.isPlayerInGame()) {
            flush(false);
            return;
        }

        Packet<?> p = e.getPacket();

        if (p instanceof S01PacketJoinGame || p instanceof S07PacketRespawn
                || p instanceof S08PacketPlayerPosLook) {
            flush();
            return;
        }

        if (p instanceof S06PacketUpdateHealth) {
            if (((S06PacketUpdateHealth) p).getHealth() <= 0.0F)
                flush();
            return;
        }

        if (p instanceof S13PacketDestroyEntities) {
            if (target != null) {
                for (int id : ((S13PacketDestroyEntities) p).getEntityIDs()) {
                    if (id == target.getEntityId()) {
                        setTarget(null);
                        break;
                    }
                }
            }
            return;
        }

        if (!isBacktracking())
            return;

        int entityId = -1;
        boolean isPositionPacket = false;
        if (p instanceof S14PacketEntity) {
            entityId = ((S14PacketEntity) p).getEntityId();
            isPositionPacket = true;
        }
        else if (p instanceof S18PacketEntityTeleport) {
            entityId = ((S18PacketEntityTeleport) p).getEntityId();
            isPositionPacket = true;
        }
        else if (p instanceof S12PacketEntityVelocity) {
            entityId = ((S12PacketEntityVelocity) p).getEntityID();
        }

        if (target != null && entityId == target.getEntityId()
                && (isPositionPacket || p instanceof S12PacketEntityVelocity)) {
            e.setCancelled(true);
            @SuppressWarnings("unchecked")
            Packet<INetHandlerPlayClient> cast = (Packet<INetHandlerPlayClient>) p;
            queue.add(new QueuedPacket(cast, System.currentTimeMillis()));
            while (queue.size() > MAX_QUEUE_SIZE) {
                QueuedPacket oldest = queue.poll();
                if (oldest != null)
                    overflow.add(oldest);
            }
        }
    }

    @Subscribe
    public void onGameLoop(GameLoopEvent e) {
        if (!Utils.Player.isPlayerInGame()) {
            flush(false);
            return;
        }

        validateTarget();

        QueuedPacket overflowed;
        while ((overflowed = overflow.poll()) != null)
            process(overflowed);

        if (queue.isEmpty())
            return;

        long now = System.currentTimeMillis();
        QueuedPacket head;
        while ((head = queue.peek()) != null && now - head.time >= currentDelay) {
            queue.poll();
            process(head);
        }

        if (queue.isEmpty())
            armDelay();
    }

    private boolean isBacktracking() {
        if (!Utils.Player.isPlayerInGame() || mc.thePlayer.isDead || !mc.thePlayer.isEntityAlive())
            return false;
        if (Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled())
            return false;
        if (target == null || target.isDead || !target.isEntityAlive())
            return false;
        return mc.thePlayer.getDistanceToEntity(target) <= range.getInput();
    }

    private void validateTarget() {
        if (target != null && !isBacktracking()) {
            flush();
            target = null;
        }
    }

    private void setTarget(EntityPlayer newTarget) {
        if (newTarget == target)
            return;

        if (newTarget == null) {
            validateTarget();
            return;
        }

        flush();
        target = newTarget;
        armDelay();
    }

    private void armDelay() {
        double lo = Math.min(delayMin.getInput(), delayMax.getInput());
        double hi = Math.max(delayMin.getInput(), delayMax.getInput());
        currentDelay = lo == hi ? (long) lo : (long) Utils.Java.randomInt(lo, hi + 0.1D);
    }

    private void process(QueuedPacket queued) {
        try {
            queued.packet.processPacket(mc.getNetHandler());
        } catch (Exception ignored) {
        }
    }

    private void flush() {
        flush(true);
    }

    /**
     * Releases every held packet immediately.
     */
    private void flush(boolean handlePackets) {
        QueuedPacket q;
        while ((q = queue.poll()) != null) {
            if (handlePackets)
                process(q);
        }
    }
}
